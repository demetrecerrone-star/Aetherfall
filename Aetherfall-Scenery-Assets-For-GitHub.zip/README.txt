# Aetherfall Quaternius scenery — 20 optimized GLB models

Prepared from the asset archives uploaded in this conversation.
Converted to standalone glTF Binary (.glb) from original Quaternius OBJ/glTF.
Texture maps for Fantasy Props and Stylized Nature downscaled
to a maximum of 512 px before embedding for Android.

Included: Houses 1–4, Inn, Blacksmith, MarketStand 1–2, Stall_Empty,
Barrel, Crate_Wooden, FarmCrate_Apple, Anvil, Lantern_Wall, BirchTree_1,
MapleTree_1, Bush, Bush_Large, Bush_Flowers, Grass_Small.

All assets by Quaternius, CC0. The ZIP is designed to be extracted
into the Godot project root `cleanroom/` during GitHub Actions.

ZIP INSTALLATION: Upload this ZIP named `Aetherfall-Scenery-Assets-For-GitHub.zip` to the
REPOSITORY ROOT on the `feature/quaternius-scenery-upgrade` branch on GitHub. DO NOT extract it before
uploading. GitHub Actions extracts and validates required assets during build.

The player character is unchanged. Fountain remains absent; four market
stalls occupy the central market. Original collision blockers are unchanged.
